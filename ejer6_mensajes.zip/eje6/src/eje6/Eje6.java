package eje6;

/**
 *
 * @author FABIAN
 */
public class Eje6 {
    public static void main(String[] args) {
        String nombre = "Juan Perez";
        int edad = 30;
        String direccion = "Calle Falsa 123";
        System.out.print("\nNombre "+nombre);
        System.out.print("\nEdad " +edad+" años");
        System.out.println("\nDireccion "+direccion);
    }
    
}