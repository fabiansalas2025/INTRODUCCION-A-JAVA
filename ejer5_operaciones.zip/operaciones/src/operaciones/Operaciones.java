package operaciones;
import java.util.Scanner;

/**
 *
 * @author FABIAN SALAS
 * Comisión 17-2025
 * Programación 2
 */
public class Operaciones {
    public static void main(String[] args) {
       Scanner entrada = new Scanner(System.in);
       //Declaración de variables
       double a,b, suma, resta, prod, div;
       //Ingreso de variables
       System.out.print("Ingrese un número :");
       a=entrada.nextDouble();
       System.out.print("Ingrese un número :");
       b=entrada.nextDouble();
       suma = a + b;
       resta = a - b;
       prod = a * b;
       div = a/b;   
      
       System.out.println("La suma es:"+suma);
       System.out.println("La resta es:"+resta);
       System.out.println("La producto es:"+prod);
       System.out.println("La división es:"+div);
    }
    
}
