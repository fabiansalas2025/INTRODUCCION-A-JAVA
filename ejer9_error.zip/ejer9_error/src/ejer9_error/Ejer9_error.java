package ejer9_error;
import java.util.Scanner;
/**
 *
 * @author FABIAN
 */
public class Ejer9_error {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingrese tu nombre :");
        // Se reemplazó donde nextInt() por nextLine()
        String  nombre = scanner.nextLine(); 
        System.out.println("Hola " +nombre);
        
    }
    
}
