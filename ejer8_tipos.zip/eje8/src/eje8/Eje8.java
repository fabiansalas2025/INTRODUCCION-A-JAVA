package eje8;
import java.util.Scanner;
/**
 *
 * @author FABIAN
 */
public class Eje8 {
    public static void main(String[] args) {
        Scanner entrada=new Scanner(System.in);
        //Declaración de variables como enteros
        int a,b, division;
        System.out.print("Ingrese un nro.: ");
        a = entrada.nextInt();
        System.out.print("Ingrese un nro.: ");
        b = entrada.nextInt();
        division= a/b; //Los decimales son truncados en la división con enteros
        System.out.println("El resultado es: "+division);
        double resultado= (double)a/b;
        System.out.println("El resultado es: "+resultado);
    }
}
